package es.alejandra.android.ejemplorecyclerview.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import es.alejandra.android.ejemplorecyclerview.R;

public class AniadirEquipoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_aniadir_equipo);
    }
}